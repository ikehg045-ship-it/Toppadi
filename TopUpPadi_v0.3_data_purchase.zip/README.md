# TopUpPadi v0.2 — Functional Flutter MVP

This version provides a working local/demo purchase flow:
Home -> Service -> Recipient/details -> Payment screen -> Demo success -> Transaction history.

IMPORTANT:
- No real money is charged.
- No real data/airtime/electricity/TV service is delivered.
- Payment and VTU APIs must be integrated through a secure backend before production.
- Never put payment/VTU secret keys inside the Flutter app.

Run:
1. Install Flutter.
2. Extract the project.
3. Run `flutter pub get`.
4. Run `flutter run`.

Production roadmap:
1. Add authentication and user database.
2. Add secure backend API.
3. Add Paystack/Flutterwave/Monnify server-side payment initialization + verification.
4. Add VTpass or another licensed VTU provider.
5. Add webhook/idempotency handling and automatic fulfillment.
6. Add admin dashboard, reconciliation, refunds and monitoring.
7. Complete business/KYC, privacy policy, terms and Play Store requirements.


## v0.3
Improved data purchase UI with network chips, selectable plans, phone validation and a clearer payment handoff. Payment remains demo-only.
