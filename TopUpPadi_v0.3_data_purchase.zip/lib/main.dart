
import 'package:flutter/material.dart';

void main() => runApp(const TopUpPadiApp());

class TopUpPadiApp extends StatelessWidget {
  const TopUpPadiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TopUpPadi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B8F55)),
        scaffoldBackgroundColor: const Color(0xFFF6F8F7),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final List<Map<String, String>> transactions = [];

  void addTransaction(String title, String amount) {
    setState(() {
      transactions.insert(0, {
        'title': title,
        'amount': amount,
        'status': 'Successful (demo)',
        'time': TimeOfDay.now().format(context),
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(onService: (service) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PurchasePage(
              service: service,
              onComplete: addTransaction,
            ),
          ),
        );
      }),
      TransactionsPage(items: transactions),
      const AccountPage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'History'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final void Function(String) onService;
  const Dashboard({super.key, required this.onService});

  @override
  Widget build(BuildContext context) {
    final services = [
      ('Data', Icons.wifi_rounded),
      ('Airtime', Icons.phone_android_rounded),
      ('Electricity', Icons.lightbulb_outline_rounded),
      ('Cable TV', Icons.tv_rounded),
      ('Internet', Icons.router_rounded),
    ];

    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: const Text('TP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Welcome to', style: TextStyle(color: Colors.grey)),
                  Text('TopUpPadi', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          ],
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              colors: [Color(0xFF0B8F55), Color(0xFF0876A8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Pay directly for every service', style: TextStyle(color: Colors.white70)),
              SizedBox(height: 8),
              Text('Fast • Simple • Secure', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
              SizedBox(height: 12),
              Text('Data, airtime, electricity, TV & internet', style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Text('Services', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: services.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.25,
          ),
          itemBuilder: (_, i) {
            final s = services[i];
            return InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => onService(s.$1),
              child: Card(
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(s.$2, size: 34, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(height: 10),
                      Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 18),
        Card(
          elevation: 0,
          child: ListTile(
            leading: const Icon(Icons.support_agent),
            title: const Text('Need help?'),
            subtitle: const Text('TopUpPadi support is available 24/7'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => showDialog(
              context: context,
              builder: (_) => const AlertDialog(
                title: Text('Support'),
                content: Text('This MVP uses demo support. Live WhatsApp/chat integration can be added later.'),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class PurchasePage extends StatefulWidget {
  final String service;
  final void Function(String, String) onComplete;
  const PurchasePage({super.key, required this.service, required this.onComplete});
  @override State<PurchasePage> createState() => _PurchasePageState();
}

class _PurchasePageState extends State<PurchasePage> {
  final number = TextEditingController();
  String network = 'MTN';
  String plan = '1 GB — ₦300';
  final dataPlans = const [
    '500 MB — ₦150', '1 GB — ₦300', '2 GB — ₦600',
    '5 GB — ₦1,500', '10 GB — ₦2,800',
  ];
  @override void dispose() { number.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buy Data')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Choose network', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: ['MTN','Airtel','Glo','9mobile'].map((n) => ChoiceChip(
          label: Text(n), selected: network == n,
          onSelected: (_) => setState(() => network = n),
        )).toList()),
        const SizedBox(height: 22),
        const Text('Choose data plan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...dataPlans.map((p) => Card(elevation: 0, child: RadioListTile<String>(
          value: p, groupValue: plan, onChanged: (v) => setState(() => plan = v!),
          title: Text(p.split('—').first.trim(), style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('Valid for 30 days'),
          secondary: Text(p.split('—').last.trim(), style: const TextStyle(fontWeight: FontWeight.bold)),
        ))),
        const SizedBox(height: 12),
        TextField(controller: number, keyboardType: TextInputType.phone, maxLength: 11,
          decoration: const InputDecoration(labelText: 'Phone number', hintText: '08012345678', prefixIcon: Icon(Icons.phone_outlined), counterText: '')),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: () {
          final phone = number.text.trim();
          if (!RegExp(r'^\d{11}$').hasMatch(phone)) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid 11-digit Nigerian phone number.'))); return;
          }
          Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentPage(
            service: '$network Data — ${plan.split('—').first.trim()}', recipient: phone,
            price: plan.split('—').last.trim(), onComplete: widget.onComplete,
          )));
        }, icon: const Icon(Icons.lock_outline), label: const Text('Continue to secure payment')),
      ]),
    );
  }
}

class PaymentPage extends StatefulWidget {
  final String service, recipient, price;
  final void Function(String, String) onComplete;
  const PaymentPage({super.key, required this.service, required this.recipient, required this.price, required this.onComplete});

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  bool processing = false;

  Future<void> pay() async {
    setState(() => processing = true);
    await Future.delayed(const Duration(seconds: 2));
    widget.onComplete(widget.service, widget.price);
    if (!mounted) return;
    setState(() => processing = false);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Payment successful'),
        content: Text('${widget.service} order created for ${widget.recipient}.\n\nDemo mode: no real money was charged and no real service was delivered.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Card(
              elevation: 0,
              child: ListTile(
                title: Text(widget.service, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('Recipient: ${widget.recipient}'),
                trailing: Text(widget.price, style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 18),
            const Text('Choose payment method', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Card(child: ListTile(leading: Icon(Icons.credit_card), title: Text('Card / Bank payment'), trailing: Icon(Icons.check_circle))),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: processing ? null : pay,
                child: processing ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Pay now'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TransactionsPage extends StatelessWidget {
  final List<Map<String, String>> items;
  const TransactionsPage({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const Center(child: Text('No transactions yet.'));
    }
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('Transaction History', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...items.map((x) => Card(
          elevation: 0,
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.check)),
            title: Text(x['title']!),
            subtitle: Text('${x['status']} • ${x['time']}'),
            trailing: Text(x['amount']!, style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        )),
      ],
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: const [
        Text('Account', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        SizedBox(height: 18),
        Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('TopUpPadi Customer'), subtitle: Text('Account setup can be connected later.'))),
        SizedBox(height: 8),
        Card(child: ListTile(leading: Icon(Icons.security), title: Text('Security'), subtitle: Text('PIN, biometrics and device security'))),
        Card(child: ListTile(leading: Icon(Icons.help_outline), title: Text('Help & Support'), subtitle: Text('Get assistance with your orders'))),
      ],
    );
  }
}
